<?php 
include_once "insrt/conn.php";
$fetch='';

for ($i=0; $i<=50000; $i++){
$queryy = "SELECT * FROM connector where initial_invest = '$i'";
 $resultt = mysqli_query($con,$queryy) or die(mysqli_error($con));
$rowss = mysqli_fetch_array($resultt);
$fetch=$rowss['initial_invest'];
 
if ($fetch == 30 )
 {
    $updatesponsor="UPDATE connector set user_stock = user_stock + 0.75 where initial_invest=30";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con)); 
    
 }
if ($fetch == 50 )
 {
    $updatesponsor="UPDATE connector set user_stock = user_stock + 1.5 where initial_invest=50";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con)); 
    
}
if ($fetch == 100 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 3 where initial_invest=100";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    
    }
if ($fetch == 150 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 4.5 where initial_invest=150";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    
    }
if ($fetch == 200 )
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 6 where initial_invest=200";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    
    }
if ($fetch == 300 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 9 where initial_invest=300";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    
    
    }
if ($fetch == 500 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 15 where initial_invest=500";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    
    }
if ($fetch == 700 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 21 where initial_invest=700";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 900 ) 
{
    $updatesponsor="UPDATE connector set user_stock = user_stock + 27 where initial_invest=900";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
     }
if ($fetch == 1500 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 45 where initial_invest=1500";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 2000 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 60 where initial_invest=2000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 3000 )
 {
    $updatesponsor="UPDATE connector set user_stock = user_stock + 90 where initial_invest=3000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 4000 )
 {
    $updatesponsor="UPDATE connector set user_stock = user_stock + 120 where initial_invest=4000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 5000 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 150 where initial_invest=5000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 10000 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 300 where initial_invest=10000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 15000 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 450 where initial_invest=15000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 20000 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 600 where initial_invest=20000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 30000 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock +900 where initial_invest=30000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }
if ($fetch == 40000 ) 
{ 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 1200 where initial_invest=40000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }

if ($fetch == 50000 )
 { 
    $updatesponsor="UPDATE connector set user_stock = user_stock + 1500 where initial_invest=50000";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));
    }

}

?>