<?php   
  include "conn.php";
  
  if (isset($_POST['request'])) {
    
    $amount = $_POST['amount'];
    $account = $_POST['account'];
    $date = date('Y-m-d');
    $status = 'requested';
    $id=$_POST['usernamee'];
   
    

    $deduct = "SELECT * FROM connector where username_='$id'";
    $results = mysqli_query($con, $deduct);
    $raw = mysqli_fetch_array($results);
    $store=($raw['user_stock'] - $_POST['amount']);
    $update="UPDATE connector set user_stock='$store'  WHERE username_='$id'";
    mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));





    $statement = "INSERT INTO payout(receiver,amount,destination,date,status)
     VALUES ('$id','$amount','$account','$date','$status')";
    mysqli_query($con,$statement) or die("error".mysqli_error($con));

    $_SESSION['message']="password has been updated";
    header("location: payout.php");
    exit;
  }else{
      echo "eroor".mysqli_error($con);
  }
  
  
?>