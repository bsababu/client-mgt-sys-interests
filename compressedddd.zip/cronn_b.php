// <?php 
// include_once "insrt/conn.php";

// $name = "sababu";

// $updatesponsor="UPDATE connector set user_incentive = user_incentive + 15 , user_stock = user_stock + 15 where username_ ='$name'";
// mysqli_query($con,$updatesponsor) or die("error".mysqli_error($con));

// ?>