<footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong>Copyright &copy; 2012-2020 <a href="https://newlusail.com">New Lusail</a>.</strong> All rights
    reserved.
  </footer>